<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    public function run(): void
    {
        $users = [
            ['username' => 'alex.reyes', 'full_name' => 'Alex Reyes'],
            ['username' => 'jamie.cruz', 'full_name' => 'Jamie Cruz'],
            ['username' => 'patricia.lim', 'full_name' => 'Patricia Lim'],
            ['username' => 'miguel.torres', 'full_name' => 'Miguel Torres'],
            ['username' => 'nicole.bautista', 'full_name' => 'Nicole Bautista'],
        ];

        foreach ($users as $user) {
            User::updateOrCreate(['username' => $user['username']], $user);
        }
    }
}
