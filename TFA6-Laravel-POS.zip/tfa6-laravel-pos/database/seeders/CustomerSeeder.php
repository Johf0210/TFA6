<?php

namespace Database\Seeders;

use App\Models\Customer;
use Illuminate\Database\Seeder;

class CustomerSeeder extends Seeder
{
    public function run(): void
    {
        $customers = [
            ['full_name' => 'Maria Santos', 'email' => 'maria.santos@example.com', 'phone' => '09180000001'],
            ['full_name' => 'Carlo Garcia', 'email' => 'carlo.garcia@example.com', 'phone' => '09180000002'],
            ['full_name' => 'Andrea Lopez', 'email' => 'andrea.lopez@example.com', 'phone' => '09180000003'],
            ['full_name' => 'Daniel Ramos', 'email' => 'daniel.ramos@example.com', 'phone' => '09180000004'],
            ['full_name' => 'Sofia Mendoza', 'email' => 'sofia.mendoza@example.com', 'phone' => '09180000005'],
        ];

        foreach ($customers as $customer) {
            Customer::updateOrCreate(['email' => $customer['email']], $customer);
        }
    }
}
