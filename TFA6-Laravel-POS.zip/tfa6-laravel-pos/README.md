# IT0049 TFA6 From Arrays to Eloquent

A Laravel 13 customer and staff directory for the POS assessment. Records are stored in a database, retrieved through Eloquent models, passed through controllers, and rendered in Blade views.

This standalone version implements the schema stated in the TFA6 handout. The previous TFA2 schema files and TFA5 application were not supplied, so matching the earlier application's exact visual layout has not been verified.

## Requirements

- PHP 8.5 is the verified runtime for the included dependency lock file.
- Composer 2 and PHP extensions including PDO SQLite, mbstring, DOM, XML, fileinfo, OpenSSL, and cURL.
- PDO MySQL if you choose MySQL instead of SQLite.
- A browser and optionally VS Code.

The pages use a local CSS file, so Node.js and a frontend build are not required.

## Quick start on this computer

Open this folder in VS Code. Double-click `start-local.cmd`, or run it in the terminal:

```powershell
.\start-local.cmd
```

The launcher uses the PHP runtime previously installed in the neighboring `laravel-tools` folder when available. Otherwise it uses PHP on PATH. It installs dependencies if necessary, creates the local configuration and database if missing, applies migrations, seeds the samples, and starts the development server.

Open <http://127.0.0.1:8000>. Press Ctrl+C in the server terminal to stop.

## Standard setup on another computer

From the project folder:

```powershell
composer install
Copy-Item .env.example .env
php artisan key:generate
php -r "file_exists('database/database.sqlite') || touch('database/database.sqlite');"
php artisan migrate --seed
php artisan serve
```

Copy `.env.example` only during initial setup; preserve an existing `.env`. SQLite is the default and needs no separate database server. The SQLite file and local `.env` are intentionally excluded from the source archive and Git.

## Use MySQL instead

Create a database named `tfa6_pos` in MySQL or phpMyAdmin. Change the database settings in your local `.env` to:

```dotenv
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=tfa6_pos
DB_USERNAME=root
DB_PASSWORD=
```

Use the actual username and password for your installation. Then run:

```powershell
php artisan config:clear
php artisan migrate --seed
```

The application and automated tests were verified with SQLite. MySQL setup is documented but has not been tested against a running MySQL server here.

## Pages

| URL | Purpose |
| --- | --- |
| `/` | Redirects to the customer directory |
| `/customers` | Displays customer ID, full name, email, and phone |
| `/users` | Displays staff ID, unique username, and full name |

These are read-only directories. Authentication, checkout, and editing forms are outside the features specified in this assessment. Staff records are directory entries, not login accounts; no passwords are seeded.

## Database schema

| Table | Fields |
| --- | --- |
| `customers` | `id`, `full_name` string(150), `email` string(255), `phone` string(30), `created_at`, `updated_at` |
| `users` | `id`, `username` string(50) unique, `full_name` string(150), `created_at`, `updated_at` |

Both IDs are auto-incrementing unsigned big integers where supported. Customer email is not given a unique database constraint because the supplied handout only explicitly requires uniqueness for usernames. Phone numbers are strings to preserve leading zeros. All three customer fields and both staff fields are required.

## Sample records

| Customer | Email | Phone |
| --- | --- | --- |
| Maria Santos | maria.santos@example.com | 09180000001 |
| Carlo Garcia | carlo.garcia@example.com | 09180000002 |
| Andrea Lopez | andrea.lopez@example.com | 09180000003 |
| Daniel Ramos | daniel.ramos@example.com | 09180000004 |
| Sofia Mendoza | sofia.mendoza@example.com | 09180000005 |

| Username | Staff full name |
| --- | --- |
| alex.reyes | Alex Reyes |
| jamie.cruz | Jamie Cruz |
| patricia.lim | Patricia Lim |
| miguel.torres | Miguel Torres |
| nicole.bautista | Nicole Bautista |

Seed arrays describe the initial data only. Controllers never use those arrays to render pages. Seeders use Eloquent `updateOrCreate`, so repeating `php artisan db:seed` updates those samples without adding duplicate records in ordinary sequential runs. Existing unrelated records remain intact.

## How the pieces fit together

1. Migrations create the database tables and constraints.
2. `DatabaseSeeder` calls the customer and user seeders inside a transaction.
3. `Customer` and `User` extend Eloquent's `Model` class and allow the relevant fields to be filled.
4. The two controllers retrieve records with `Model::query()->orderBy('full_name')->get()`.
5. Routes connect URLs to the controllers.
6. Blade views loop over the returned collections using `@forelse`. Empty tables show a helpful message, and `{{ }}` escapes stored text.

## Important source files

- `database/migrations/0001_01_01_000000_create_users_table.php`
- `database/migrations/0001_01_01_000001_create_customers_table.php`
- `database/seeders/CustomerSeeder.php`
- `database/seeders/UserSeeder.php`
- `database/seeders/DatabaseSeeder.php`
- `app/Models/Customer.php` and `app/Models/User.php`
- `app/Http/Controllers/CustomerController.php` and `UserController.php`
- `routes/web.php`
- `resources/views/customers/index.blade.php`
- `resources/views/users/index.blade.php`
- `resources/views/layouts/app.blade.php`
- `public/css/app.css`

## Verify the project

```powershell
php artisan test
php artisan migrate:status
```

Feature tests check database-backed page rendering, five seeded records per table, repeated seeding, unique usernames, empty states, escaped output, and the home redirect. Tests use a separate SQLite database in memory and do not erase the local database.

To reverse the schema in a disposable database, `php artisan migrate:rollback` calls the migrations' `down()` methods. This removes the corresponding tables and their records.

## Screenshots

![Customer directory](docs/customers-desktop.png)

![Staff directory](docs/users-desktop.png)

Mobile screenshots are also included in `docs/`. On narrow screens, the customer table scrolls horizontally so contact details remain readable.

## Submission checklist

- Upload the raw source files to your GitHub repository, including `composer.lock`, both migrations, all seeders, models, controllers, views, and this README.
- Do not upload `.env`, `vendor`, local SQLite files, or log files. Dependencies are restored with Composer.
- Deploy to a PHP-capable host, run migrations and seeders, and verify both pages.
- Set `APP_ENV=production`, `APP_DEBUG=false`, the real `APP_URL`, and a private `APP_KEY` on the host. Keep the database on persistent storage. Set the web root to `public`.
- Submit your GitHub repository URL and the working hosted URL. A local address such as `localhost:8000` is not a hosted submission link.
- If exact TFA5 presentation is required, compare these pages against the earlier project before submission.

Repository publication and hosting were not performed for this standalone version.

## Migrations compared with manual MySQL tables

Migrations describe database changes as version-controlled PHP files. Laravel tracks which migrations have run, applies pending changes in order, and can reverse changes through their `down()` methods. This helps developers reproduce the same schema on different computers.

Manually creating tables means executing SQL or using a tool such as phpMyAdmin. Those changes are not automatically registered in Laravel's migration history. Both approaches can create tables in MySQL; migrations provide a repeatable record of the changes. Seeders insert initial data, while Eloquent retrieves and manipulates the stored records.

## References

- [Laravel migrations](https://laravel.com/docs/13.x/migrations)
- [Laravel seeders](https://laravel.com/docs/13.x/seeding)
- [Laravel Eloquent](https://laravel.com/docs/13.x/eloquent)
- [Laravel Blade](https://laravel.com/docs/13.x/blade)
