<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class DirectoryTest extends TestCase
{
    use RefreshDatabase;

    public function test_home_redirects_to_customers(): void
    {
        $this->get('/')->assertRedirect('/customers');
    }

    public function test_seeders_create_five_records_per_table_and_can_run_twice(): void
    {
        $this->seed();
        $this->seed();

        $this->assertDatabaseCount('customers', 5);
        $this->assertDatabaseCount('users', 5);
        $this->assertDatabaseHas('customers', ['full_name' => 'Maria Santos', 'phone' => '09180000001']);
        $this->assertDatabaseHas('users', ['username' => 'jamie.cruz', 'full_name' => 'Jamie Cruz']);
    }

    public function test_customer_page_reads_database_records_instead_of_static_arrays(): void
    {
        Customer::create(['full_name' => 'Database Customer', 'email' => 'database@example.com', 'phone' => '09000000001']);

        $this->get('/customers')->assertOk()->assertViewIs('customers.index')
            ->assertSee('Database Customer')->assertSee('database@example.com')->assertSee('09000000001');
    }

    public function test_staff_page_reads_database_records_instead_of_static_arrays(): void
    {
        User::create(['username' => 'database.staff', 'full_name' => 'Database Staff']);

        $this->get('/users')->assertOk()->assertViewIs('users.index')
            ->assertSee('database.staff')->assertSee('Database Staff');
    }

    public function test_empty_directories_render_without_errors(): void
    {
        $this->get('/customers')->assertOk()->assertSee('No customers yet.');
        $this->get('/users')->assertOk()->assertSee('No staff records yet.');
    }

    public function test_blade_escapes_customer_names(): void
    {
        Customer::create(['full_name' => '<script>alert(1)</script>', 'email' => 'escape@example.com', 'phone' => '09000000002']);

        $this->get('/customers')->assertOk()
            ->assertSee('&lt;script&gt;alert(1)&lt;/script&gt;', false)
            ->assertDontSee('<script>alert(1)</script>', false);
    }

    public function test_database_rejects_duplicate_usernames(): void
    {
        User::create(['username' => 'same.username', 'full_name' => 'First Staff']);

        $this->expectException(\Illuminate\Database\QueryException::class);

        User::create(['username' => 'same.username', 'full_name' => 'Second Staff']);
    }
}
