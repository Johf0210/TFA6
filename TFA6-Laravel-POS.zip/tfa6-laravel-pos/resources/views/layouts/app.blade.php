<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title') | Corner POS</title>
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
    <header class="site-header">
        <div class="header-inner">
            <a class="brand" href="{{ route('customers.index') }}"><span class="brand-mark" aria-hidden="true">C</span> Corner <span class="brand-light">POS</span></a>
            <span class="header-label">Store directory</span>
        </div>
    </header>
    <main class="page">
        <div class="eyebrow">YOUR PEOPLE, IN ONE PLACE</div>
        <div class="page-heading">
            <div><h1>@yield('title')</h1><p class="intro">@yield('description')</p></div>
            <span class="count-pill">@yield('count') records</span>
        </div>
        <nav class="tabs" aria-label="Record directories">
            <a href="{{ route('customers.index') }}" @class(['tab', 'is-active' => request()->routeIs('customers.*')]) @if(request()->routeIs('customers.*')) aria-current="page" @endif>Customers</a>
            <a href="{{ route('users.index') }}" @class(['tab', 'is-active' => request()->routeIs('users.*')]) @if(request()->routeIs('users.*')) aria-current="page" @endif>Users / Staff</a>
        </nav>
        @yield('content')
        <footer class="page-footer"><span>Corner POS</span><span>Customer and staff directory</span></footer>
    </main>
</body>
</html>
