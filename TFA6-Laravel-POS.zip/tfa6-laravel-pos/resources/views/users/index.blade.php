@extends('layouts.app')

@section('title', 'Users / Staff')
@section('description', 'See the people who keep your store running.')
@section('count', (string) $users->count())

@section('content')
<section class="directory" aria-labelledby="directory-title">
    <div class="directory-heading"><h2 id="directory-title">Staff directory</h2><span>Team members</span></div>
    <div class="table-scroll" tabindex="0" role="region" aria-label="Staff records">
        <table>
            <caption class="visually-hidden">Staff IDs, usernames, and full names</caption>
            <thead><tr><th scope="col">ID</th><th scope="col">Username</th><th scope="col">Full name</th></tr></thead>
            <tbody>
            @forelse ($users as $user)
                <tr>
                    <td class="record-id">{{ $user->id }}</td>
                    <td><span class="username">{{ $user->username }}</span></td>
                    <td class="person-name">{{ $user->full_name }}</td>
                </tr>
            @empty
                <tr><td colspan="3" class="empty-state">No staff records yet.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    <div class="table-footer">{{ $users->count() }} {{ $users->count() === 1 ? 'team member' : 'team members' }} in your directory</div>
</section>
@endsection
