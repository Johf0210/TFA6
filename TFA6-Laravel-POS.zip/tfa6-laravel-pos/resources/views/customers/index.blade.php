@extends('layouts.app')

@section('title', 'Customers')
@section('description', 'Find customer names and contact details for your store.')
@section('count', (string) $customers->count())

@section('content')
<section class="directory" aria-labelledby="directory-title">
    <div class="directory-heading"><h2 id="directory-title">Customer directory</h2><span>Contact information</span></div>
    <div class="table-scroll" tabindex="0" role="region" aria-label="Customer records">
        <table>
            <caption class="visually-hidden">Customer IDs, full names, email addresses, and phone numbers</caption>
            <thead><tr><th scope="col">ID</th><th scope="col">Full name</th><th scope="col">Email address</th><th scope="col">Phone number</th></tr></thead>
            <tbody>
            @forelse ($customers as $customer)
                <tr>
                    <td class="record-id">{{ $customer->id }}</td>
                    <td class="person-name">{{ $customer->full_name }}</td>
                    <td>{{ $customer->email }}</td>
                    <td class="phone">{{ $customer->phone }}</td>
                </tr>
            @empty
                <tr><td colspan="4" class="empty-state">No customers yet.</td></tr>
            @endforelse
            </tbody>
        </table>
    </div>
    <div class="table-footer">{{ $customers->count() }} {{ $customers->count() === 1 ? 'customer' : 'customers' }} in your directory</div>
</section>
@endsection
