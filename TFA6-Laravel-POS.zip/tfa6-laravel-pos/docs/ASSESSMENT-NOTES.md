# Assessment notes

## What changed from arrays to Eloquent

The customer and staff controllers query their corresponding Eloquent models. The customer and staff lists are no longer defined as arrays in the controllers. Arrays appear only in the seeders, where they describe initial sample records to insert into the database.

For a request to `/customers`, Laravel follows this sequence:

1. The route calls `CustomerController::index()`.
2. The controller retrieves customer records through `Customer::query()->orderBy('full_name')->get()`.
3. Eloquent returns a collection of `Customer` objects.
4. The controller passes the collection to `customers.index`.
5. Blade loops through the collection and displays each customer's stored values.

The `/users` page follows the same sequence with `UserController`, `User`, and `users.index`.

## Why these fields were chosen

The customer table contains the handout's required `full_name`, `email`, and `phone`. The users table contains `username` and `full_name`, with a database unique constraint on `username`. Each table also has an ID and timestamps for Eloquent's standard record handling.

Phone numbers are stored as strings because they are identifiers, not quantities; storing them as numbers could remove the initial zero. Usernames are unique so two staff records cannot share the same username.

## Migrations and seeders

Migrations create or change the table structure. Seeders insert sample records after the tables exist. This project uses separate customer and user seeders called by `DatabaseSeeder`.

The migrations define reverse operations in `down()`. The seeders use `updateOrCreate` so rerunning the sample seeders does not add another copy of the same sample in ordinary sequential runs.

## Verification

- Eight automated tests passed, with 24 assertions.
- The tests create and query a separate SQLite database in memory.
- Browser checks confirmed both pages return HTTP 200 and display five rows.
- Navigation works between both directories.
- Desktop and mobile screenshots were inspected.
- SQLite migrations and sample seeding completed successfully.

MySQL is documented as an alternative connection; an active MySQL server was not available for verification. GitHub publication and hosting are separate submission steps. Exact visual parity with the previous TFA5 application cannot be confirmed without that application.
